###Project: Simple Rigidbody Character Controller

####Description: Rigidbody character controller constrained to the X and Y axis to move left and right as well as jump.

####Tutorial Used: BMS Unity3D: Simple custom player controller

####Tutorial URI: http://youtu.be/jjFrpWdBZ6s

####Completion Date: 09 May 2014

**Created in Unity**

Simple rigidbody controller constrained to the XY axis with the ability to jump. Did now know how to do this for the last Ludum Dare and wanted to document how with a working version.

**Controls**
--------------
A and D or Left and Right arrows: Move space: Jump