###Fire Exit

####Created for Ludum Dare 29
####Theme: "Beneath the Surface"

**Created as a team with Uncade: http://www.uncade.com/**
-------------------------------------------------------------------------

My first completed game created for Ludum Dare 29 game jam. It is a puzzle game where you move two characters at the top and bottom of the level (who are on fire but not getting hurt ^_^) to try and get them to the exit. You are able to flip the stage so you can get a different perspective of the level. 

You can play the web version of the game here: https://db.tt/T5CP3DAd

####How to Play
------------------------------
**Keyboard:**
A and D | Arrow keys = Move
Space = Jump
Left Alt or B = Flip the Stage

**Xbox Controller:**
Left Analog/ D-pad = Move
A button = Jump
B button = Flip the stage