A test level for a Unity Third Person Controller with a camera following. I have the player follow camera working properly, but the rotate around has some problems with it's angles. I have small pickups that are placed around the level. The pickups are counted on the left side of the screen. Once all of the pickups are gathered by the player, "You Win!" will appear at the bottom of the pickup counter. 

The level was created with the combination of several YouTube tutorials:
Code referenced from Quill18Creates - Simple FPS Shooter Tutorial

--Video #1: http://youtu.be/mbm9lPB5GPw

--Video #2: http://youtu.be/rhpJPx8fICQ

--Video #3: http://youtu.be/mHk21MHyuqI

Pickup and Counter referenced Unity Roll-A-Ball Tutorial: 
--http://unity3d.com/learn/tutorials/projects/roll-a-ball


---Controls---
Keyboard: 
WASD - Movement
Spacebar - Jump

Controller: (work in progress)
--Based on Xbox Controller--
Left Analog: movement
Right Analog: Camera (work in progress)
A button: Jump
