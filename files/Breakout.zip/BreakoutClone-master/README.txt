This is a 2D brick game setup to play like Breakout created in Unity3d. It was completed by following the tutorial on the YouTube Channel Quill18Creates. You can find the tutorial series by going here: http://www.youtube.com/playlist?list=PLCD6B6D279036462A

The project is written in C# and uses images from CGTextures. (http://www.cgtextures.com/)

It took me a few hours to complete this tutorial since I was still new to Unity at the time and had to use Google to find most of the components I needed to use. 

I'm glad I was able to create this since it is the first game that I was able to make that has gameplay, win/lose conditions, and a scoring system set up. The game immediately starts on Level 01. 

Controls:

Move Paddle: Left and Right Arrow Keys or A and D keys
Launch Ball: Spacebar

I also have the standalone file available for PC, Mac and Linux. (BreakClone.exe)

