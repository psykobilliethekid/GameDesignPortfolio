This is the completed "Roll A Ball" game created from the Unity tutorial in the beginners section of the Unity3d site. The tutorial can be found here: http://unity3d.com/learn/tutorials/projects/roll-a-ball

The objective of the game is to move the player sphere using WASD or the arrow keys to pick up the rotating cubes in the play field. The count of the cubes is tallied and displayed in the upper left corner of the screen. Once all of the cubes have been collected, the player is shown the victory text. 

The shadows are not able to be shown since this is the free version of Unity and not Unity Pro. 