####Respawning Pickup Version 02
#####Created by Dani Moss
#####Made in Unity 4.5.0f6

**Controls:** 
WASD / Arrow keys = movement

A test game I created to figure out how to respawn a pickup using Instantiate and Random.Range(). Got some help from the Unity forums with this one and I'm glad we were able to get things working.  

You can play the game here: https://db.tt/NHIwyR9b