####Respawning Pickup Version 01
#####Created by Dani Moss
#####Made in Unity 4.5.0f6

**Controls:** 
WASD / Arrow keys = movement
Space = Jump

A test game I created to figure out how to respawn a pickup in the same place using SetActive(). Took quite some time to figure out but I was able to get things working with the aid of Unity Answers. 

You can play the game here: https://db.tt/mN1bQARi